"""The daily dispatch model and the multi-day simulation loop.

Dispatch order for each day, as described in the plan:

1. Solar supplies the load first; any surplus charges the battery.
2. When solar is insufficient, the battery supplies the rest of the load until
   it reaches the configured generator-start SOC.
3. The generator then supplies the remaining load and recharges the battery.
   The energy it must produce determines its running hours and fuel burn.

Each day ends by carrying its battery and fuel state into the next day.
"""

from __future__ import annotations

from fuelsim.config import HOURS_PER_DAY, SimulationConfig
from fuelsim.results import DayRecord, SimulationResult

# Energy smaller than this counts as zero, so float noise cannot start a
# generator or leave a sliver of unserved load behind.
ENERGY_EPSILON_KWH = 1e-9


def _generator_hours_for(
    config: SimulationConfig, energy_kwh: float, fuel_l: float
) -> tuple[float, bool]:
    """Running hours needed for ``energy_kwh``, capped by the day and by fuel.

    Returns the hours and whether the fuel remaining was the binding constraint.
    """
    hours = min(energy_kwh / config.gen_rated_kw, HOURS_PER_DAY)

    if config.gen_fuel_lph <= 0.0:
        return hours, False

    affordable_hours = fuel_l / config.gen_fuel_lph
    if affordable_hours < hours:
        return affordable_hours, True
    return hours, False


def simulate_day(
    config: SimulationConfig, *, day: int, battery_kwh: float, fuel_l: float
) -> DayRecord:
    """Run one day of dispatch from the given starting battery and fuel state."""
    battery_start_kwh = battery_kwh
    load_kwh = config.daily_load_kwh
    solar_kwh = config.daily_solar_kwh

    # 1. Solar serves the load, then charges the battery with whatever is left.
    solar_to_load = min(solar_kwh, load_kwh)
    load_remaining = load_kwh - solar_to_load
    solar_surplus = solar_kwh - solar_to_load

    headroom_kwh = max(config.max_battery_kwh - battery_kwh, 0.0)
    acceptable_surplus = headroom_kwh / config.battery_charge_efficiency
    solar_to_battery = min(solar_surplus, acceptable_surplus)
    solar_curtailed = solar_surplus - solar_to_battery
    battery_kwh += solar_to_battery * config.battery_charge_efficiency

    ***********************************
        ***********************************
            *********************************************************************************************************
    # 2. The battery covers the rest of the load down to the generator-start SOC.
    stored_above_floor = max(battery_kwh - config.gen_start_battery_kwh, 0.0)
    battery_to_load = min(
        load_remaining, stored_above_floor * config.battery_discharge_efficiency
    )
    battery_kwh -= battery_to_load / config.battery_discharge_efficiency
    load_remaining -= battery_to_load

    # 3. The generator covers the remaining load and recharges the pack.
    generator_to_load = 0.0
    generator_to_battery = 0.0
    generator_hours = 0.0
    fuel_used = 0.0
    fuel_limited = False
    unserved_load = 0.0

    if load_remaining > ENERGY_EPSILON_KWH:
        recharge_need = max(config.gen_stop_battery_kwh - battery_kwh, 0.0)
        wanted_energy = load_remaining + recharge_need / config.battery_charge_efficiency
        generator_hours, fuel_limited = _generator_hours_for(config, wanted_energy, fuel_l)

        produced = generator_hours * config.gen_rated_kw
        generator_to_load = min(produced, load_remaining)
        generator_to_battery = produced - generator_to_load
        battery_kwh += generator_to_battery * config.battery_charge_efficiency

        unserved_load = load_remaining - generator_to_load
        fuel_used = min(generator_hours * config.gen_fuel_lph, fuel_l)

    return DayRecord(
        day=day,
        load_kwh=load_kwh,
        solar_kwh=solar_kwh,
        solar_to_load_kwh=solar_to_load,
        solar_to_battery_kwh=solar_to_battery,
        solar_curtailed_kwh=solar_curtailed,
        battery_to_load_kwh=battery_to_load,
        generator_to_load_kwh=generator_to_load,
        generator_to_battery_kwh=generator_to_battery,
        generator_energy_kwh=generator_to_load + generator_to_battery,
        generator_hours=generator_hours,
        fuel_used_l=fuel_used,
        fuel_limited=fuel_limited,
        unserved_load_kwh=unserved_load,
        battery_start_kwh=battery_start_kwh,
        battery_end_kwh=battery_kwh,
        soc_start_pct=config.soc_pct_at(battery_start_kwh),
        soc_end_pct=config.soc_pct_at(battery_kwh),
        fuel_start_l=fuel_l,
        fuel_end_l=fuel_l - fuel_used,
    )


def run_simulation(config: SimulationConfig) -> SimulationResult:
    """Step the model day by day until fuel hits the threshold or time runs out."""
    if config.fuel_level_l <= config.fuel_threshold_l:
        return SimulationResult(config=config, days=(), days_until_threshold=0)

    battery_kwh = config.initial_battery_kwh
    fuel_l = config.fuel_level_l
    days: list[DayRecord] = []
    days_until_threshold = None

    for day in range(1, config.max_days + 1):
        record = simulate_day(config, day=day, battery_kwh=battery_kwh, fuel_l=fuel_l)
        days.append(record)
        battery_kwh = record.battery_end_kwh
        fuel_l = record.fuel_end_l

        if fuel_l <= config.fuel_threshold_l:
            days_until_threshold = day
            break

    return SimulationResult(
        config=config, days=tuple(days), days_until_threshold=days_until_threshold
    )
