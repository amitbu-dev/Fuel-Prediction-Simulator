"""Per-day records, the simulation result, and how a prediction is presented."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import TYPE_CHECKING, Optional, Sequence

if TYPE_CHECKING:  # pragma: no cover - typing only
    import pandas as pd

    from fuelsim.config import SimulationConfig


@dataclass(frozen=True)
class DayRecord:
    """One simulated day.

    Load-side fields (``*_to_load_kwh``) are energy delivered to the load.
    Charge-side fields (``*_to_battery_kwh``) are energy taken from the source
    and routed to the battery, before charging losses. The two invariants the
    engine maintains are::

        solar_kwh           == solar_to_load + solar_to_battery + solar_curtailed
        generator_energy    == generator_to_load + generator_to_battery
    """

    day: int

    load_kwh: float
    solar_kwh: float

    solar_to_load_kwh: float
    solar_to_battery_kwh: float
    solar_curtailed_kwh: float

    battery_to_load_kwh: float

    generator_to_load_kwh: float
    generator_to_battery_kwh: float
    generator_energy_kwh: float
    generator_hours: float
    fuel_used_l: float
    fuel_limited: bool

    unserved_load_kwh: float

    battery_start_kwh: float
    battery_end_kwh: float
    soc_start_pct: float
    soc_end_pct: float
    fuel_start_l: float
    fuel_end_l: float


def format_days_until(days_until_threshold: Optional[int], *, horizon_days: int) -> str:
    """Render the headline answer, capping anything past the reporting horizon.

    ``None`` means the threshold was never reached inside the simulated window,
    which reads the same as "further away than we are willing to claim".
    """
    if horizon_days < 1:
        raise ValueError(f"horizon_days must be >= 1, got {horizon_days!r}")
    if days_until_threshold is None or days_until_threshold > horizon_days:
        return f">{horizon_days} days"
    if days_until_threshold < 0:
        raise ValueError(
            f"days_until_threshold must be >= 0, got {days_until_threshold!r}"
        )
    unit = "day" if days_until_threshold == 1 else "days"
    return f"{days_until_threshold} {unit}"


@dataclass(frozen=True)
class SimulationResult:
    """The outcome of a run: the headline answer plus the full trajectory."""

    config: "SimulationConfig"
    days: Sequence[DayRecord] = field(default_factory=tuple)
    days_until_threshold: Optional[int] = None

    @property
    def reached_threshold(self) -> bool:
        return self.days_until_threshold is not None

    @property
    def days_display(self) -> str:
        return format_days_until(
            self.days_until_threshold, horizon_days=self.config.report_horizon_days
        )

    def summary(self) -> str:
        """One-line, human-readable statement of the prediction."""
        threshold = self.config.fuel_threshold_l
        return (
            f"Fuel reaches the {threshold:g} L threshold in {self.days_display} "
            f"(from {self.config.fuel_level_l:g} L, "
            f"load {self.config.current_load_kw:g} kW, "
            f"solar {self.config.solar_capacity_kw:g} kW)."
        )

    def to_frame(self) -> "pd.DataFrame":
        """Daily trajectory as a pandas DataFrame indexed by day number."""
        import pandas as pd

        if not self.days:
            return pd.DataFrame(columns=[f.name for f in DAY_RECORD_FIELDS])
        return pd.DataFrame([asdict(day) for day in self.days])


DAY_RECORD_FIELDS = tuple(DayRecord.__dataclass_fields__.values())
