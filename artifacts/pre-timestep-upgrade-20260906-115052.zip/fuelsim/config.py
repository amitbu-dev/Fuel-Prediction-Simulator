"""Configuration and day-zero inputs for the fuel-prediction simulator.

Units used throughout the package:

* energy  - kWh
* power   - kW
* fuel    - liters (L)
* SOC     - percent of nominal battery capacity (0-100)
* time    - hours, except the simulation step which is one day
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace

HOURS_PER_DAY = 24.0
DEFAULT_SOLAR_HOURS_PER_DAY = 5.0
DEFAULT_REPORT_HORIZON_DAYS = 30
DEFAULT_MAX_DAYS = 60
PERCENT = 100.0


def _require_finite(name: str, value: float) -> float:
    if not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number, got {value!r}")
    return value


def _require_non_negative(name: str, value: float) -> None:
    _require_finite(name, value)
    if value < 0.0:
        raise ValueError(f"{name} must be >= 0, got {value!r}")


def _require_positive(name: str, value: float) -> None:
    _require_finite(name, value)
    if value <= 0.0:
        raise ValueError(f"{name} must be > 0, got {value!r}")


def _require_percent(name: str, value: float) -> None:
    _require_finite(name, value)
    if not 0.0 <= value <= PERCENT:
        raise ValueError(f"{name} must be between 0 and 100, got {value!r}")


def _require_efficiency(name: str, value: float) -> None:
    _require_finite(name, value)
    if not 0.0 < value <= 1.0:
        raise ValueError(f"{name} must be in (0, 1], got {value!r}")


@dataclass(frozen=True)
class SimulationConfig:
    """Day-zero measurements plus the system constants the simulator needs.

    The first four fields are the actual system measurements listed in the plan;
    everything after them is a configured system parameter with a PoC default.
    """

    # Day-zero measurements
    battery_soc_pct: float
    fuel_level_l: float
    solar_capacity_kw: float
    current_load_kw: float

    # System parameters
    battery_capacity_kwh: float
    gen_start_soc_pct: float
    gen_rated_kw: float
    gen_fuel_lph: float

    # Tunables with PoC defaults
    gen_stop_soc_pct: float = PERCENT
    max_soc_pct: float = PERCENT
    fuel_threshold_l: float = 0.0
    solar_hours_per_day: float = DEFAULT_SOLAR_HOURS_PER_DAY
    battery_charge_efficiency: float = 1.0
    battery_discharge_efficiency: float = 1.0
    max_days: int = DEFAULT_MAX_DAYS
    report_horizon_days: int = DEFAULT_REPORT_HORIZON_DAYS

    def __post_init__(self) -> None:
        _require_percent("battery_soc_pct", self.battery_soc_pct)
        _require_non_negative("fuel_level_l", self.fuel_level_l)
        _require_non_negative("solar_capacity_kw", self.solar_capacity_kw)
        _require_non_negative("current_load_kw", self.current_load_kw)

        _require_positive("battery_capacity_kwh", self.battery_capacity_kwh)
        _require_percent("gen_start_soc_pct", self.gen_start_soc_pct)
        _require_positive("gen_rated_kw", self.gen_rated_kw)
        _require_non_negative("gen_fuel_lph", self.gen_fuel_lph)

        _require_percent("gen_stop_soc_pct", self.gen_stop_soc_pct)
        _require_percent("max_soc_pct", self.max_soc_pct)
        _require_non_negative("fuel_threshold_l", self.fuel_threshold_l)
        _require_efficiency("battery_charge_efficiency", self.battery_charge_efficiency)
        _require_efficiency("battery_discharge_efficiency", self.battery_discharge_efficiency)

        _require_finite("solar_hours_per_day", self.solar_hours_per_day)
        if not 0.0 <= self.solar_hours_per_day <= HOURS_PER_DAY:
            raise ValueError(
                "solar_hours_per_day must be between 0 and 24, "
                f"got {self.solar_hours_per_day!r}"
            )

        if self.gen_stop_soc_pct < self.gen_start_soc_pct:
            raise ValueError(
                "gen_stop_soc_pct must be >= gen_start_soc_pct "
                f"({self.gen_stop_soc_pct!r} < {self.gen_start_soc_pct!r})"
            )
        if self.gen_stop_soc_pct > self.max_soc_pct:
            raise ValueError(
                "gen_stop_soc_pct must be <= max_soc_pct "
                f"({self.gen_stop_soc_pct!r} > {self.max_soc_pct!r})"
            )
        if self.max_days < 1:
            raise ValueError(f"max_days must be >= 1, got {self.max_days!r}")
        if self.report_horizon_days < 1:
            raise ValueError(
                f"report_horizon_days must be >= 1, got {self.report_horizon_days!r}"
            )

    # -- derived values ----------------------------------------------------

    @property
    def daily_load_kwh(self) -> float:
        """Daily consumption estimated from the momentary load (load x 24 h)."""
        return self.current_load_kw * HOURS_PER_DAY

    @property
    def daily_solar_kwh(self) -> float:
        """Daily production from the fixed production-hours assumption."""
        return self.solar_capacity_kw * self.solar_hours_per_day

    def battery_kwh_at(self, soc_pct: float) -> float:
        """Stored energy corresponding to a state of charge."""
        return self.battery_capacity_kwh * soc_pct / PERCENT

    def soc_pct_at(self, kwh: float) -> float:
        """State of charge corresponding to a stored energy."""
        return kwh / self.battery_capacity_kwh * PERCENT

    @property
    def initial_battery_kwh(self) -> float:
        return self.battery_kwh_at(self.battery_soc_pct)

    @property
    def max_battery_kwh(self) -> float:
        return self.battery_kwh_at(self.max_soc_pct)

    @property
    def gen_start_battery_kwh(self) -> float:
        """Battery floor: below this the generator takes over the load."""
        return self.battery_kwh_at(self.gen_start_soc_pct)

    @property
    def gen_stop_battery_kwh(self) -> float:
        """Battery level the generator recharges to before shutting down."""
        return self.battery_kwh_at(self.gen_stop_soc_pct)

    def with_changes(self, **changes) -> "SimulationConfig":
        """Return a validated copy with the given fields replaced."""
        return replace(self, **changes)
