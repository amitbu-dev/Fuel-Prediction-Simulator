"""Matplotlib views of a simulation run, for use inside the notebook."""

from __future__ import annotations

from typing import TYPE_CHECKING

import matplotlib.pyplot as plt

from fuelsim.results import SimulationResult

if TYPE_CHECKING:  # pragma: no cover - typing only
    from matplotlib.figure import Figure

SOURCE_COLUMNS = (
    ("solar_to_load_kwh", "Solar", "#f2b134"),
    ("battery_to_load_kwh", "Battery", "#4a90d9"),
    ("generator_to_load_kwh", "Generator", "#8c8c8c"),
    ("unserved_load_kwh", "Unserved", "#d0021b"),
)


def _require_days(result: SimulationResult) -> None:
    if not result.days:
        raise ValueError("nothing to plot: the simulation produced no days")


def plot_trajectory(result: SimulationResult, *, figsize=(10, 8)) -> "Figure":
    """SOC, fuel level, and generator runtime over the simulated days."""
    _require_days(result)
    frame = result.to_frame()
    config = result.config

    fig, (soc_ax, fuel_ax, gen_ax) = plt.subplots(
        3, 1, figsize=figsize, sharex=True, constrained_layout=True
    )
    fig.suptitle(result.summary(), fontsize=11)

    soc_ax.plot(frame["day"], frame["soc_end_pct"], marker="o", color="#4a90d9")
    soc_ax.axhline(
        config.gen_start_soc_pct,
        color="#d0021b",
        linestyle="--",
        linewidth=1,
        label=f"generator start ({config.gen_start_soc_pct:g}%)",
    )
    soc_ax.set_ylabel("Battery SOC (%)")
    soc_ax.set_ylim(0, 105)
    soc_ax.legend(loc="lower left", fontsize=8)
    soc_ax.grid(alpha=0.3)

    fuel_ax.plot(frame["day"], frame["fuel_end_l"], marker="o", color="#417505")
    fuel_ax.axhline(
        config.fuel_threshold_l,
        color="#d0021b",
        linestyle="--",
        linewidth=1,
        label=f"threshold ({config.fuel_threshold_l:g} L)",
    )
    fuel_ax.set_ylabel("Fuel remaining (L)")
    fuel_ax.legend(loc="lower left", fontsize=8)
    fuel_ax.grid(alpha=0.3)

    gen_ax.bar(frame["day"], frame["generator_hours"], color="#8c8c8c")
    gen_ax.set_ylabel("Generator (h/day)")
    gen_ax.set_xlabel("Day")
    gen_ax.set_ylim(0, max(frame["generator_hours"].max() * 1.2, 1.0))
    gen_ax.grid(alpha=0.3, axis="y")

    return fig


def plot_daily_energy(result: SimulationResult, *, figsize=(10, 4)) -> "Figure":
    """Stacked view of which source served the load each day."""
    _require_days(result)
    frame = result.to_frame()

    fig, ax = plt.subplots(figsize=figsize, constrained_layout=True)
    bottom = frame["day"] * 0.0
    for column, label, color in SOURCE_COLUMNS:
        values = frame[column]
        if values.abs().max() == 0.0:
            continue
        ax.bar(frame["day"], values, bottom=bottom, label=label, color=color)
        bottom = bottom + values

    ax.set_title("Daily load coverage by source")
    ax.set_xlabel("Day")
    ax.set_ylabel("Energy (kWh)")
    ax.legend(loc="upper right", fontsize=8)
    ax.grid(alpha=0.3, axis="y")

    return fig
