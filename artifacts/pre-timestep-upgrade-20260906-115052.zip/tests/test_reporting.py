"""Tests for how a prediction is presented to a user."""

import pytest

from fuelsim.engine import run_simulation
from fuelsim.results import format_days_until
from tests.test_simulation import reference_config


class TestFormatDaysUntil:
    def test_beyond_the_horizon_is_reported_as_greater_than(self):
        assert format_days_until(31, horizon_days=30) == ">30 days"

    def test_never_reached_is_reported_as_greater_than(self):
        assert format_days_until(None, horizon_days=30) == ">30 days"

    def test_exactly_the_horizon_is_reported_as_a_number(self):
        assert format_days_until(30, horizon_days=30) == "30 days"

    def test_inside_the_horizon_is_reported_as_a_number(self):
        assert format_days_until(6, horizon_days=30) == "6 days"

    def test_one_day_is_singular(self):
        assert format_days_until(1, horizon_days=30) == "1 day"

    def test_already_at_the_threshold_is_zero_days(self):
        assert format_days_until(0, horizon_days=30) == "0 days"

    def test_horizon_is_configurable(self):
        assert format_days_until(8, horizon_days=7) == ">7 days"

    def test_rejects_a_non_positive_horizon(self):
        with pytest.raises(ValueError, match="horizon_days"):
            format_days_until(3, horizon_days=0)

    def test_rejects_a_negative_day_count(self):
        with pytest.raises(ValueError, match="days_until_threshold"):
            format_days_until(-1, horizon_days=30)


class TestResultSummary:
    def test_result_renders_its_own_headline(self):
        result = run_simulation(reference_config())

        assert result.days_display == "6 days"

    def test_long_running_scenario_renders_the_capped_headline(self):
        config = reference_config(solar_capacity_kw=20.0, max_days=45)

        result = run_simulation(config)

        assert result.days_display == ">30 days"

    def test_a_result_past_the_horizon_but_inside_max_days_is_capped(self):
        # 300 L of fuel at 9.6 L/day lasts ~32 days, past the 30 day horizon.
        config = reference_config(fuel_level_l=300.0, max_days=60)

        result = run_simulation(config)

        assert result.days_until_threshold == 32
        assert result.days_display == ">30 days"

    def test_summary_mentions_the_threshold(self):
        result = run_simulation(reference_config(fuel_threshold_l=10.0))

        summary = result.summary()

        assert "10" in summary
        assert "5 days" in summary
