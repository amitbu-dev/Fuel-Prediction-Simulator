"""Single-day dispatch tests: solar -> load -> battery -> generator."""

import pytest

from fuelsim.config import SimulationConfig
from fuelsim.engine import simulate_day
from tests.test_config import make_config


def run_day(config: SimulationConfig, *, soc_kwh=None, fuel_l=None):
    return simulate_day(
        config,
        day=1,
        battery_kwh=config.initial_battery_kwh if soc_kwh is None else soc_kwh,
        fuel_l=config.fuel_level_l if fuel_l is None else fuel_l,
    )


class TestSolarDispatch:
    def test_solar_covers_load_exactly_and_nothing_else_runs(self):
        # 4.8 kW x 5 h = 24 kWh/day == 1 kW x 24 h load
        config = make_config(solar_capacity_kw=4.8, current_load_kw=1.0, battery_soc_pct=50.0)

        day = run_day(config)

        assert day.solar_to_load_kwh == pytest.approx(24.0)
        assert day.solar_to_battery_kwh == pytest.approx(0.0)
        assert day.battery_to_load_kwh == pytest.approx(0.0)
        assert day.generator_energy_kwh == pytest.approx(0.0)
        assert day.generator_hours == pytest.approx(0.0)
        assert day.fuel_used_l == pytest.approx(0.0)
        assert day.battery_end_kwh == pytest.approx(config.initial_battery_kwh)

    def test_solar_surplus_charges_the_battery(self):
        # 10 kW x 5 h = 50 kWh solar, 24 kWh load -> 26 kWh surplus, 5 kWh headroom
        config = make_config(
            solar_capacity_kw=10.0,
            current_load_kw=1.0,
            battery_capacity_kwh=10.0,
            battery_soc_pct=50.0,
        )

        day = run_day(config)

        assert day.solar_to_load_kwh == pytest.approx(24.0)
        assert day.solar_to_battery_kwh == pytest.approx(5.0)
        assert day.solar_curtailed_kwh == pytest.approx(21.0)
        assert day.battery_end_kwh == pytest.approx(10.0)
        assert day.generator_energy_kwh == pytest.approx(0.0)

    def test_charge_efficiency_reduces_stored_solar_energy(self):
        config = make_config(
            solar_capacity_kw=10.0,
            current_load_kw=1.0,
            battery_capacity_kwh=100.0,
            battery_soc_pct=0.0,
            gen_start_soc_pct=0.0,
            battery_charge_efficiency=0.5,
        )

        day = run_day(config)

        # 26 kWh routed to the battery, 13 kWh actually stored
        assert day.solar_to_battery_kwh == pytest.approx(26.0)
        assert day.solar_curtailed_kwh == pytest.approx(0.0)
        assert day.battery_end_kwh == pytest.approx(13.0)


class TestBatteryDispatch:
    def test_battery_covers_deficit_down_to_generator_start_soc(self):
        # No solar, 24 kWh load, 10 kWh battery with a 2 kWh floor -> 8 kWh from battery
        config = make_config(
            battery_capacity_kwh=10.0, battery_soc_pct=100.0, gen_start_soc_pct=20.0
        )

        day = run_day(config)

        assert day.battery_to_load_kwh == pytest.approx(8.0)
        assert day.generator_to_load_kwh == pytest.approx(16.0)

    def test_battery_at_generator_start_soc_contributes_nothing(self):
        config = make_config(battery_soc_pct=20.0, gen_start_soc_pct=20.0)

        day = run_day(config)

        assert day.battery_to_load_kwh == pytest.approx(0.0)
        assert day.generator_to_load_kwh == pytest.approx(24.0)

    def test_battery_below_generator_start_soc_contributes_nothing(self):
        config = make_config(battery_soc_pct=10.0, gen_start_soc_pct=20.0)

        day = run_day(config)

        assert day.battery_to_load_kwh == pytest.approx(0.0)

    def test_discharge_efficiency_reduces_delivered_energy(self):
        config = make_config(
            battery_capacity_kwh=10.0,
            battery_soc_pct=100.0,
            gen_start_soc_pct=20.0,
            battery_discharge_efficiency=0.5,
        )

        day = run_day(config)

        # 8 kWh available in the pack delivers only 4 kWh to the load
        assert day.battery_to_load_kwh == pytest.approx(4.0)


class TestGeneratorDispatch:
    def test_generator_serves_load_and_recharges_battery(self):
        config = make_config(
            battery_capacity_kwh=10.0,
            battery_soc_pct=100.0,
            gen_start_soc_pct=20.0,
            gen_stop_soc_pct=100.0,
            gen_rated_kw=5.0,
            gen_fuel_lph=2.0,
        )

        day = run_day(config)

        assert day.generator_to_load_kwh == pytest.approx(16.0)
        assert day.generator_to_battery_kwh == pytest.approx(8.0)
        assert day.generator_energy_kwh == pytest.approx(24.0)
        assert day.generator_hours == pytest.approx(4.8)
        assert day.fuel_used_l == pytest.approx(9.6)
        assert day.battery_end_kwh == pytest.approx(10.0)
        assert day.fuel_end_l == pytest.approx(config.fuel_level_l - 9.6)

    def test_generator_stops_charging_at_configured_stop_soc(self):
        config = make_config(
            battery_capacity_kwh=10.0,
            battery_soc_pct=100.0,
            gen_start_soc_pct=20.0,
            gen_stop_soc_pct=80.0,
            max_soc_pct=100.0,
        )

        day = run_day(config)

        assert day.generator_to_battery_kwh == pytest.approx(6.0)
        assert day.battery_end_kwh == pytest.approx(8.0)

    def test_generator_runtime_is_capped_at_24_hours(self):
        # 40 kW load -> 960 kWh/day, a 5 kW generator can only deliver 120 kWh
        config = make_config(
            current_load_kw=40.0,
            battery_soc_pct=20.0,
            gen_start_soc_pct=20.0,
            gen_rated_kw=5.0,
            gen_fuel_lph=2.0,
            fuel_level_l=1000.0,
        )

        day = run_day(config)

        assert day.generator_hours == pytest.approx(24.0)
        assert day.generator_to_load_kwh == pytest.approx(120.0)
        assert day.unserved_load_kwh == pytest.approx(840.0)
        assert day.fuel_used_l == pytest.approx(48.0)

    def test_generator_runtime_is_capped_by_remaining_fuel(self):
        config = make_config(gen_rated_kw=5.0, gen_fuel_lph=2.0)

        day = run_day(config, fuel_l=3.0)

        assert day.generator_hours == pytest.approx(1.5)
        assert day.fuel_used_l == pytest.approx(3.0)
        assert day.fuel_end_l == pytest.approx(0.0)
        assert day.fuel_limited is True

    def test_a_zero_fuel_rate_generator_is_never_fuel_limited(self):
        config = make_config(gen_fuel_lph=0.0, gen_rated_kw=5.0)

        day = run_day(config, fuel_l=0.0)

        assert day.generator_hours == pytest.approx(4.8)
        assert day.fuel_used_l == pytest.approx(0.0)
        assert day.fuel_limited is False

    def test_unlimited_generator_runtime_is_not_fuel_limited(self):
        config = make_config()

        day = run_day(config)

        assert day.fuel_limited is False

    def test_generator_prioritises_load_over_charging_when_runtime_is_short(self):
        config = make_config(
            battery_capacity_kwh=10.0,
            battery_soc_pct=20.0,
            gen_start_soc_pct=20.0,
            gen_stop_soc_pct=100.0,
            gen_rated_kw=5.0,
            gen_fuel_lph=2.0,
        )

        # 2 L of fuel buys 1 h -> 5 kWh, all of which must go to the 24 kWh load
        day = run_day(config, fuel_l=2.0)

        assert day.generator_to_load_kwh == pytest.approx(5.0)
        assert day.generator_to_battery_kwh == pytest.approx(0.0)
        assert day.unserved_load_kwh == pytest.approx(19.0)
        assert day.battery_end_kwh == pytest.approx(2.0)


class TestEnergyBalance:
    @pytest.mark.parametrize(
        "overrides",
        [
            {},
            {"solar_capacity_kw": 10.0},
            {"solar_capacity_kw": 3.0, "battery_soc_pct": 55.0},
            {"current_load_kw": 40.0, "fuel_level_l": 1000.0},
            {"battery_charge_efficiency": 0.9, "battery_discharge_efficiency": 0.95},
        ],
    )
    def test_sources_and_sinks_balance(self, overrides):
        config = make_config(**overrides)

        day = run_day(config)

        served = day.solar_to_load_kwh + day.battery_to_load_kwh + day.generator_to_load_kwh
        assert served + day.unserved_load_kwh == pytest.approx(day.load_kwh)

        solar_used = day.solar_to_load_kwh + day.solar_to_battery_kwh + day.solar_curtailed_kwh
        assert solar_used == pytest.approx(day.solar_kwh)

        assert day.generator_energy_kwh == pytest.approx(
            day.generator_to_load_kwh + day.generator_to_battery_kwh
        )

        charged = (
            day.solar_to_battery_kwh + day.generator_to_battery_kwh
        ) * config.battery_charge_efficiency
        discharged = day.battery_to_load_kwh / config.battery_discharge_efficiency
        assert day.battery_end_kwh - day.battery_start_kwh == pytest.approx(charged - discharged)

    def test_battery_never_leaves_its_bounds(self):
        config = make_config(solar_capacity_kw=50.0, battery_soc_pct=99.0, max_soc_pct=100.0)

        day = run_day(config)

        assert 0.0 <= day.battery_end_kwh <= config.max_battery_kwh + 1e-9

    def test_soc_percentages_mirror_stored_energy(self):
        config = make_config(battery_capacity_kwh=10.0, battery_soc_pct=100.0)

        day = run_day(config)

        assert day.soc_start_pct == pytest.approx(100.0)
        assert day.soc_end_pct == pytest.approx(day.battery_end_kwh / 10.0 * 100.0)
