"""Multi-day simulation tests: carry-over, termination, and the headline answer."""

import pytest

from fuelsim.engine import run_simulation
from tests.test_config import make_config


# Hand-computed reference scenario, no solar:
#   load      = 1 kW x 24 h                       = 24.0 kWh/day
#   battery   = 10 kWh, 100% -> 20% floor         =  8.0 kWh to the load
#   generator = 16 kWh to load + 8 kWh recharge   = 24.0 kWh @ 5 kW -> 4.8 h
#   fuel      = 4.8 h x 2 L/h                     =  9.6 L/day
# Starting from 50 L: 40.4, 30.8, 21.2, 11.6, 2.0, then day 6 runs dry.
REFERENCE_FUEL_PER_DAY_L = 9.6


REFERENCE_INPUTS = dict(
    solar_capacity_kw=0.0,
    current_load_kw=1.0,
    battery_capacity_kwh=10.0,
    battery_soc_pct=100.0,
    gen_start_soc_pct=20.0,
    gen_stop_soc_pct=100.0,
    gen_rated_kw=5.0,
    gen_fuel_lph=2.0,
    fuel_level_l=50.0,
    fuel_threshold_l=0.0,
)


def reference_config(**overrides):
    return make_config(**{**REFERENCE_INPUTS, **overrides})


class TestCarryOver:
    def test_each_day_starts_where_the_previous_day_ended(self):
        result = run_simulation(reference_config())

        for previous, current in zip(result.days, result.days[1:]):
            assert current.battery_start_kwh == pytest.approx(previous.battery_end_kwh)
            assert current.fuel_start_l == pytest.approx(previous.fuel_end_l)

    def test_first_day_starts_from_the_measured_day_zero_inputs(self):
        config = reference_config()

        first = run_simulation(config).days[0]

        assert first.day == 1
        assert first.battery_start_kwh == pytest.approx(config.initial_battery_kwh)
        assert first.fuel_start_l == pytest.approx(config.fuel_level_l)

    def test_fuel_never_increases(self):
        result = run_simulation(reference_config())

        for previous, current in zip(result.days, result.days[1:]):
            assert current.fuel_end_l <= previous.fuel_end_l + 1e-9


class TestTermination:
    def test_reports_the_day_the_tank_hits_the_threshold(self):
        result = run_simulation(reference_config(fuel_threshold_l=0.0))

        assert result.reached_threshold is True
        assert result.days_until_threshold == 6
        assert result.days[-1].fuel_end_l == pytest.approx(0.0)

    def test_a_higher_threshold_is_reached_sooner(self):
        result = run_simulation(reference_config(fuel_threshold_l=10.0))

        assert result.days_until_threshold == 5
        assert result.days[-1].fuel_end_l == pytest.approx(2.0)

    def test_simulation_stops_on_the_terminating_day(self):
        result = run_simulation(reference_config())

        assert len(result.days) == 6

    def test_day_zero_already_below_threshold_reports_zero_days(self):
        config = reference_config(fuel_level_l=5.0, fuel_threshold_l=10.0)

        result = run_simulation(config)

        assert result.days_until_threshold == 0
        assert result.days == ()

    def test_stops_at_max_days_when_the_threshold_is_never_reached(self):
        # Plenty of solar: the generator never starts, so fuel never moves.
        config = reference_config(solar_capacity_kw=20.0, max_days=15)

        result = run_simulation(config)

        assert result.reached_threshold is False
        assert result.days_until_threshold is None
        assert len(result.days) == 15
        assert result.days[-1].fuel_end_l == pytest.approx(config.fuel_level_l)


class TestFuelPerDay:
    def test_steady_state_burns_the_expected_fuel_each_day(self):
        result = run_simulation(reference_config())

        for day in result.days[:5]:
            assert day.fuel_used_l == pytest.approx(REFERENCE_FUEL_PER_DAY_L)

    def test_solar_reduces_generator_runtime(self):
        without_solar = run_simulation(reference_config())
        with_solar = run_simulation(reference_config(solar_capacity_kw=2.0))

        assert with_solar.days[0].generator_hours < without_solar.days[0].generator_hours
        assert with_solar.days[0].fuel_used_l < without_solar.days[0].fuel_used_l


class TestFrame:
    def test_to_frame_has_one_row_per_simulated_day(self):
        result = run_simulation(reference_config())

        frame = result.to_frame()

        assert len(frame) == len(result.days)
        assert list(frame["day"]) == [day.day for day in result.days]

    def test_to_frame_exposes_the_trajectory_columns(self):
        result = run_simulation(reference_config())

        frame = result.to_frame()

        for column in ("soc_end_pct", "fuel_end_l", "generator_hours", "fuel_used_l"):
            assert column in frame.columns

    def test_to_frame_of_an_empty_simulation_is_empty(self):
        result = run_simulation(reference_config(fuel_level_l=0.0, fuel_threshold_l=0.0))

        assert result.to_frame().empty
