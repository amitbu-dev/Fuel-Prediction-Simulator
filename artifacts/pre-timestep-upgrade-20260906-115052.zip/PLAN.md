# Fuel Prediction — PoC Plan

Status: PoC implemented and validated. See `Implementation` below.
Date: 2026-08-30 (plan) / 2026-08-30 (implementation)

## Goal

Start with a simple PoC simulator and validate the logic before improving its accuracy.

Output: estimated number of days until fuel drops below a configured threshold.
Any result beyond 30 days is displayed as ">30 days" (irrelevant for now, because the
solar forecast values are hardcoded).

## Assumptions

- The reported battery SOC is accurate and is used as the simulation's starting point.
- The simulator steps on a **daily** basis.

## Day 0 inputs (actual system measurements)

- Battery SOC
- Fuel level
- Installed solar capacity
- Current (momentary) load

## Daily model

1. **Daily load consumption** — initially estimated from the momentary load:
   `current load x 24 h`
2. **Daily solar production** — fixed five-hour production assumption:
   `installed solar capacity x 5 h`
   (e.g. 2 kW solar ~= 10 kWh/day)
3. **Dispatch order**
   - Solar supplies the load first; any surplus charges the battery.
   - When solar is insufficient, the battery supplies the remaining load until it
     reaches the configured generator-start SOC.
   - The generator then supplies the load and charges the battery. The required
     generator energy determines its operating hours and fuel consumption.
4. **Carry-over** — each day's ending battery SOC and fuel level become the next day's
   starting values, producing the predicted SOC and fuel trajectories.
5. **Termination** — the simulation continues until the fuel tank reaches a configured
   threshold.

## Implementation approach

First version in a **Python Jupyter Notebook**, so we can change input parameters, test
many scenarios, and visualize predicted SOC, generator operation, and remaining fuel
over time.

## Implementation

    fuelsim/config.py      SimulationConfig - day-0 inputs, system parameters, validation
    fuelsim/controller.py  controller-row parser -> SimulationConfig adapter
    fuelsim/engine.py      simulate_day() dispatch + run_simulation() day loop
    fuelsim/results.py     DayRecord, SimulationResult, the ">30 days" formatting rule
    fuelsim/plotting.py    trajectory and daily-energy charts
    tests/                 97 tests, 100% statement coverage of fuelsim
    fuel_prediction_poc.ipynb   inputs, the answer, curves, sanity checks, sweeps

The model logic sits in `fuelsim/` rather than in notebook cells so it can be unit
tested; the notebook is where inputs get changed and scenarios explored.

Run the tests:

    .venv\Scripts\python.exe -m pytest --cov=fuelsim --cov-report=term-missing

### Parameters the plan did not name but the model needs

- `battery_capacity_kwh` - the plan gives SOC as a percentage, which is meaningless for
  an energy balance without a capacity to multiply it by.
- `gen_stop_soc_pct` - the plan says the generator "charges the battery" but not to what
  level. Defaults to 100%.
- `gen_rated_kw` and `gen_fuel_lph` - needed to turn required generator energy into
  operating hours and then into liters.

Optional, defaulted to lossless so they can be ignored for the PoC:
`battery_charge_efficiency`, `battery_discharge_efficiency`, `max_soc_pct`.

### Guards the model applies

- Generator runtime is capped at 24 h/day; load it cannot cover is recorded as
  `unserved_load_kwh` rather than silently vanishing.
- Generator runtime is also capped by the fuel actually left in the tank
  (`fuel_limited`), so the tank cannot go negative.
- The run stops at `max_days` (default 60) when the threshold is never reached, which is
  what produces `>30 days` for a site the generator never starts on.

### Baseline: the AlphaM controller configuration

The notebook baseline is the `AlphaM Config` controller row, parsed by
`fuelsim/controller.py` rather than transcribed into a cell. The positional column
layout is declared once in `CONTROLLER_COLUMNS`, so correcting a wrong guess is a
one-line change.

**The mapping was inferred from the values, not from a schema.** Columns marked
UNVERIFIED in `controller.py` are guesses. Two inputs the simulator needs are absent
from the row because they are live measurements, not settings, and must be supplied:
`battery_soc_pct` (required explicitly) and a real `current_load_kw` reading (the
column value is itself a guess).

Before adopting the mapping it was checked against the alternatives: swapping
`battery_capacity_kwh` (30) with `gen_start_soc_pct` (20), and reading 190 rather than
180 as the current fuel level, **all give the same answer of 4 days**. The battery
parameters wash out for the reason described below, so the remaining ambiguity does not
move the prediction. `tests/test_controller.py` pins this.

### What validation surfaced

- **The load estimate dominates, and steeply.** On AlphaM: 2 kW gives 14 days, 3 kW
  gives 7, 5 kW gives 4, and below ~1.5 kW the site is self-sufficient at `>30 days`.
  A 1 kW error in the momentary reading is worth several days. This is the case for the
  averaged-load next step.
- **Beyond ~6 kW the load sweep flattens at 3 days, and that is the tank, not the load.**
  180 L at 60 L/day is three days regardless of extra load, which simply becomes
  `unserved_load_kwh`. The flat region is not insensitivity.
- **`gen_start_soc_pct` has no effect on the prediction.** Because the generator
  recharges to `gen_stop_soc_pct` on every day it runs, the net battery contribution per
  day is fixed and moving the floor only reshuffles energy within the day. This is
  correct for a daily-bucket model, but it means the PoC **cannot** be used to evaluate
  generator-start-SOC policy - that needs sub-daily steps. The same reasoning is why
  battery capacity barely matters, and why the ambiguous columns above are harmless.
- **AlphaM is generator-bound, not battery-bound.** A 6 kW generator against a
  120 kWh/day load runs ~15.8 h/day; the 30 kWh battery covers only 24 kWh of the 95 kWh
  daily deficit. Fuel logistics dominate this site.

## Next step after validation

Once the PoC behaves logically, improve the load estimate using configurable averages
(e.g. previous two hours, or previous day) to make the prediction less sensitive to
momentary load changes.

## Environment

Scratch folder (not a git repo). Local venv at `.venv` (Python 3.14.4, created with uv).

Installed: jupyterlab 4.6.3, notebook 7.6.2, ipykernel 7.3.0, numpy 2.5.2,
pandas 3.0.5, matplotlib 3.11.1.

Launch:

    cd C:\Users\amitb\Workspace\NanoGridX-FuelPrediction
    .venv\Scripts\jupyter.exe lab

Add packages later with:

    uv pip install --python .venv <package>
